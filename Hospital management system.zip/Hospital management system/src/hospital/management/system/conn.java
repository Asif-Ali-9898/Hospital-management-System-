package hospital.management.system;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
wt HEJYfMfxmhfmhgh.xhjmgmhfv
public class conn {
    public Connection connection;
    public Statement statement;

    public conn() {
        try {
            // Adjust these parameters as needed
            String url = "jdbc:mysql://localhost:3306/hospital_management_system";
            Stringhnf user = "root";
            String password = "asif@9897";

            // Initialize the connection
            connection = DriverManager.getConnection(url, user, password);
            System.out.println("Asif your are connected with database :");

            // Initialize the statement
            statement = connection.createStatement();
        } catch (Exception e) {
            e.printStackTrace(); // Debugging purposes
        }
    }
}
